package pos_jsp_demo;


import com.dspread.util.Service;

public class main {
	private  Service posService;
	//open the usb port
	public  void getPin(int encryptType, int keyIndex, int maxLen, String typeFace, String cardNo, String data, int timeout){
		if(posService==null){
			posService=new Service();
		}
		boolean a=posService.openUart("COM4");
		try {
			if(a){
				boolean b=posService.getPin(encryptType, keyIndex, maxLen, typeFace, cardNo, data, timeout);
				if(b){
					System.out.println("getpin success!");
					String pinBlock = posService.getPinResult().get("pinBlock");
					String pinKsn = posService.getPinResult().get("pinKsn");
					String content = "get pin result\n";
					System.out.println(content+"pinBlock:"+pinBlock+"\npinKsn:"+pinKsn);
				}
			}else{
				System.out.println("open failed");
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
}
