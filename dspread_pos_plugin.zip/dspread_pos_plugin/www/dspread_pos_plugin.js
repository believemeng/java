cordova.define("posPlugin.dspread_pos_plugin", function(require, exports, module) {
var exec = require('cordova/exec');

var posPlug =function(){};
posPlug.prototype.scanQPos2Mode=function(){
  exec(null,null,"dspread_pos_plugin","scanQPos2Mode",[]);
}

posPlug.prototype.connectBluetoothDevice=function(isConnect){
  exec(null,null,"dspread_pos_plugin","connectBluetoothDevice",[isConnect]);
}

posPlug.prototype.doTrade=function(timeout){
	  exec(null,null,"dspread_pos_plugin","doTrade",[timeout]);
	}

posPlug.prototype.getDeviceList=function(){
	  exec(null,null,"dspread_pos_plugin","getDeviceList",[]);
	}
var  pos=new posPlug();
module.exports=pos;

});
